# ABS Smart Parking Free Out for Android

This is the standalone Android client for documentation-only Free Out work. It connects to the parking server over the local network and uses the server's configured Free Out reasons and audit records. It does not use camera, Bluetooth, barrier, or other parking hardware permissions.

## Build on GitHub

1. Create or open a GitHub repository and upload the contents of this ZIP to its root.
2. Push the files to the repository. GitHub Actions runs **Android Free Out** for pushes and pull requests. You can also run it from **Actions → Android Free Out → Run workflow**.
3. Open the completed workflow run and download the `abs-free-out-debug-apk` artifact.

The workflow installs JDK 17, Gradle 8.7 and Android API 35 build tools, then runs `assembleDebug`. Android Gradle Plugin 8.6.1 requires Gradle 8.7. The project can also be opened directly in Android Studio.

## Connect to the parking server

Install the APK on the Android device, enter the server computer's LAN address such as `http://192.168.1.20:5000`, then sign in with a FreeOut account. Keep the Android device and server connected to the same local network. The app supports recording a vehicle number, selecting a configured Free Out reason, adding a remark, and filtering recent Free Out records.

The app uses cleartext HTTP for a private LAN server URL. Use it only on a trusted network; change the server URL to HTTPS after deploying the parking system behind a domain and TLS certificate.

## Project layout

- `app/` — Android application source and manifest
- `build.gradle`, `settings.gradle` — Gradle project configuration
- `.github/workflows/android-build.yml` — GitHub Actions build and APK artifact workflow
