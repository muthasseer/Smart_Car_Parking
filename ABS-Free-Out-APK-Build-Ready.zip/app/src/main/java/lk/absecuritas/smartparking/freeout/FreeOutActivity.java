package lk.absecuritas.smartparking.freeout;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputFilter;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.CookieManager;
import java.net.CookiePolicy;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class FreeOutActivity extends Activity {
    private static final String PREFS = "abs_free_out";
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final ArrayList<String> reasons = new ArrayList<>();
    private String baseUrl = "";
    private String fullName = "";
    private String role = "";
    private LinearLayout root;
    private EditText hostField, usernameField, passwordField, plateField, remarkField, filterField;
    private Spinner reasonSpinner;
    private Button saveButton;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        CookieManager cookies = new CookieManager(null, CookiePolicy.ACCEPT_ALL);
        java.net.CookieHandler.setDefault(cookies);
        baseUrl = getPreferences(MODE_PRIVATE).getString("server", "");
        showLogin();
    }

    private void showLogin() {
        root = page();
        title(root, "ABS SMART PARKING", "Free Out · LAN connected");
        hostField = input(root, "Server URL (example: http://192.168.1.20:5000)", false);
        hostField.setText(baseUrl);
        usernameField = input(root, "Username", false);
        usernameField.setSingleLine(true);
        passwordField = input(root, "Password", true);
        Button login = button("SIGN IN", true);
        root.addView(login, matchWrap());
        TextView note = text("Use the server computer's LAN IP and port 5000. No camera, barrier or hardware permission is used by this app.", 13, MUTED);
        note.setPadding(0, 16, 0, 0);
        root.addView(note, matchWrap());
        login.setOnClickListener(v -> signIn(login));
        setContentView(wrap(root));
    }

    private void signIn(Button login) {
        final String server = normalizeServer(hostField.getText().toString());
        final String username = usernameField.getText().toString().trim().toUpperCase();
        final String password = passwordField.getText().toString();
        if (server == null || username.isEmpty() || password.isEmpty()) {
            message("Enter a valid LAN server URL, username and password."); return;
        }
        login.setEnabled(false); login.setText("CONNECTING…");
        io.execute(() -> {
            try {
                formPost(server + "/login", "username=" + enc(username) + "&password=" + enc(password));
                JSONObject session = getJson(server + "/api/mobile/session");
                baseUrl = server;
                fullName = session.optString("full_name", username);
                role = session.optString("role", "");
                getPreferences(MODE_PRIVATE).edit().putString("server", server).apply();
                runOnUiThread(() -> { hideKeyboard(); showFreeOut(); loadReasons(); loadHistory(""); });
            } catch (Exception ex) {
                runOnUiThread(() -> { login.setEnabled(true); login.setText("SIGN IN"); message(userMessage(ex)); });
            }
        });
    }

    private void showFreeOut() {
        root = page();
        title(root, "FREE OUT", fullName + " · " + role.replace('_', ' '));
        TextView server = text("LAN SERVER  " + baseUrl, 12, MUTED);
        server.setPadding(0, 0, 0, 16);
        root.addView(server, matchWrap());
        plateField = input(root, "Vehicle number", false);
        plateField.setSingleLine(true);
        plateField.setFilters(new InputFilter[]{new InputFilter.AllCaps(), new InputFilter.LengthFilter(24)});
        reasonSpinner = new Spinner(this);
        root.addView(label("Free Out reason"), matchWrap());
        root.addView(reasonSpinner, matchWrap());
        remarkField = input(root, "Remark (optional)", false);
        saveButton = button("SAVE FREE OUT", true);
        LinearLayout.LayoutParams saveParams = matchWrap(); saveParams.topMargin = dp(10);
        root.addView(saveButton, saveParams);
        saveButton.setOnClickListener(v -> saveFreeOut());
        LinearLayout section = new LinearLayout(this); section.setOrientation(LinearLayout.HORIZONTAL); section.setGravity(Gravity.CENTER_VERTICAL);
        TextView historyTitle = text("Recent Free Out Records", 17, NAVY); historyTitle.setTypeface(null, 1);
        section.addView(historyTitle, new LinearLayout.LayoutParams(0, dp(48), 1));
        Button logout = button("LOG OUT", false); section.addView(logout, new LinearLayout.LayoutParams(dp(104), dp(42)));
        logout.setOnClickListener(v -> signOut());
        root.addView(section, matchWrap());
        filterField = input(root, "Filter by vehicle number", false);
        filterField.setSingleLine(true);
        Button search = button("SEARCH", false); root.addView(search, matchWrap());
        search.setOnClickListener(v -> loadHistory(filterField.getText().toString().trim()));
        LinearLayout history = new LinearLayout(this); history.setOrientation(LinearLayout.VERTICAL); history.setId(View.generateViewId()); root.addView(history, matchWrap());
        root.setTag(history);
        setContentView(wrap(root));
    }

    private void loadReasons() {
        io.execute(() -> {
            try {
                JSONArray rows = getArray(baseUrl + "/api/mobile/free-out-reasons");
                reasons.clear();
                for (int i = 0; i < rows.length(); i++) reasons.add(rows.getJSONObject(i).optString("reason"));
                runOnUiThread(() -> {
                    ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, reasons);
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    reasonSpinner.setAdapter(adapter);
                    if (reasons.isEmpty()) message("No active Free Out reasons are configured. Ask an Admin to add one.");
                });
            } catch (Exception ex) { runOnUiThread(() -> message(userMessage(ex))); }
        });
    }

    private void saveFreeOut() {
        String plate = plateField.getText().toString().trim().toUpperCase();
        if (plate.isEmpty()) { message("Enter the vehicle number."); return; }
        if (reasons.isEmpty()) { message("There are no active Free Out reasons."); return; }
        JSONObject data = new JSONObject();
        try { data.put("plate", plate); data.put("category", String.valueOf(reasonSpinner.getSelectedItem())); data.put("remark", remarkField.getText().toString().trim()); }
        catch (Exception ex) { message("Could not prepare the Free Out record."); return; }
        saveButton.setEnabled(false); saveButton.setText("SAVING…");
        io.execute(() -> {
            try {
                JSONObject result = postJson(baseUrl + "/api/mobile/free-outs", data);
                runOnUiThread(() -> {
                    saveButton.setEnabled(true); saveButton.setText("SAVE FREE OUT");
                    plateField.setText(""); remarkField.setText(""); message(result.optString("message", "Saved.")); loadHistory("");
                });
            } catch (Exception ex) { runOnUiThread(() -> { saveButton.setEnabled(true); saveButton.setText("SAVE FREE OUT"); message(userMessage(ex)); }); }
        });
    }

    private void loadHistory(String plate) {
        io.execute(() -> {
            try {
                JSONArray rows = getArray(baseUrl + "/api/mobile/free-outs?plate=" + enc(plate));
                runOnUiThread(() -> {
                    LinearLayout list = (LinearLayout) root.getTag(); list.removeAllViews();
                    if (rows.length() == 0) { list.addView(text("No free out records found.", 13, MUTED), matchWrap()); return; }
                    for (int i=0; i<rows.length(); i++) {
                        JSONObject row = rows.optJSONObject(i); if (row == null) continue;
                        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(13), dp(10), dp(13), dp(10));
                        card.setBackgroundColor(Color.WHITE); LinearLayout.LayoutParams cp = matchWrap(); cp.topMargin = dp(8); card.setLayoutParams(cp);
                        TextView vehicle = text(row.optString("plate") + "  ·  " + row.optString("category"), 15, NAVY); vehicle.setTypeface(null, 1); card.addView(vehicle, matchWrap());
                        card.addView(text(row.optString("created_at") + (row.optString("remark").isEmpty() ? "" : "  ·  " + row.optString("remark")), 12, MUTED), matchWrap());
                        list.addView(card, matchWrap());
                    }
                });
            } catch (Exception ex) { runOnUiThread(() -> message(userMessage(ex))); }
        });
    }

    private void signOut() {
        io.execute(() -> { try { request("GET", baseUrl + "/logout", null); } catch (Exception ignored) {}
            runOnUiThread(() -> { baseUrl = getPreferences(MODE_PRIVATE).getString("server", ""); showLogin(); }); });
    }

    private JSONObject postJson(String url, JSONObject data) throws Exception { return new JSONObject(request("POST", url, data.toString(), "application/json")); }
    private JSONObject getJson(String url) throws Exception { return new JSONObject(request("GET", url, null, null)); }
    private JSONArray getArray(String url) throws Exception { return new JSONArray(request("GET", url, null, null)); }
    private String formPost(String url, String body) throws Exception { return request("POST", url, body, "application/x-www-form-urlencoded; charset=UTF-8"); }

    private String request(String method, String address, String body, String contentType) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(address).openConnection();
        connection.setRequestMethod(method); connection.setConnectTimeout(12000); connection.setReadTimeout(15000);
        connection.setInstanceFollowRedirects(true); connection.setRequestProperty("Accept", "application/json, text/html;q=0.8");
        if (body != null) {
            connection.setDoOutput(true); connection.setRequestProperty("Content-Type", contentType);
            try (OutputStream out = connection.getOutputStream()) { out.write(body.getBytes(StandardCharsets.UTF_8)); }
        }
        int code = connection.getResponseCode();
        InputStream input = code >= 400 ? connection.getErrorStream() : connection.getInputStream();
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        if (input != null) { try (InputStream in = input) { byte[] chunk = new byte[4096]; int n; while ((n=in.read(chunk))!=-1) buffer.write(chunk,0,n); } }
        String result = buffer.toString("UTF-8"); connection.disconnect();
        if (code < 200 || code >= 300) {
            try { String error = new JSONObject(result).optString("error", "HTTP " + code); throw new Exception(error); }
            catch (org.json.JSONException ignored) { throw new Exception("Server returned HTTP " + code); }
        }
        return result;
    }

    private String normalizeServer(String raw) {
        String value = raw.trim().replaceAll("/+$", "");
        if (value.isEmpty()) return null;
        if (!value.startsWith("http://") && !value.startsWith("https://")) value = "http://" + value;
        try { URL url = new URL(value); if (url.getHost().isEmpty() || url.getQuery()!=null || url.getRef()!=null) return null; }
        catch (Exception ex) { return null; }
        return value;
    }

    private String enc(String value) { try { return URLEncoder.encode(value, "UTF-8"); } catch (Exception ex) { return ""; } }
    private String userMessage(Exception ex) { return ex.getMessage()==null ? "Connection failed. Check the LAN URL and server." : ex.getMessage(); }
    private void hideKeyboard() { try { ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(root.getWindowToken(),0); } catch (Exception ignored) {} }
    private void message(String value) { new AlertDialog.Builder(this).setTitle("ABS Free Out").setMessage(value).setPositiveButton("OK",null).show(); }

    private LinearLayout page() {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(18),dp(18),dp(18),dp(24)); box.setBackgroundColor(Color.rgb(242,245,250)); return box;
    }
    private ScrollView wrap(LinearLayout content) {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        content.setLayoutParams(p); scroll.addView(content); return scroll;
    }
    private void title(LinearLayout box, String heading, String subtitle) {
        TextView h = text(heading, 22, NAVY); h.setTypeface(null,1); box.addView(h, matchWrap());
        TextView s = text(subtitle,13,MUTED); s.setPadding(0,dp(3),0,dp(20)); box.addView(s,matchWrap());
    }
    private EditText input(LinearLayout box, String hint, boolean secret) {
        TextView label = label(hint); box.addView(label,matchWrap());
        EditText edit = new EditText(this); edit.setSingleLine(!hint.startsWith("Remark")); edit.setTextSize(15); edit.setPadding(dp(12),dp(8),dp(12),dp(8));
        edit.setBackgroundColor(Color.WHITE); edit.setHint(secret ? "••••••••" : hint);
        if (secret) edit.setInputType(129);
        LinearLayout.LayoutParams p = matchWrap(); p.bottomMargin=dp(13); box.addView(edit,p); return edit;
    }
    private TextView label(String value) { TextView t=text(value,12,NAVY);t.setTypeface(null,1);t.setPadding(0,dp(3),0,dp(5));return t; }
    private TextView text(String value,int size,int color) { TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);return t; }
    private Button button(String value,boolean primary) { Button b=new Button(this);b.setText(value);b.setTextSize(13);b.setAllCaps(false);b.setTextColor(primary?Color.WHITE:NAVY);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(primary?BLUE:Color.rgb(226,233,243)));return b; }
    private LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
    private static final int NAVY=Color.rgb(16,34,72), MUTED=Color.rgb(105,122,147), BLUE=Color.rgb(23,105,210);

    @Override protected void onDestroy() { io.shutdownNow(); super.onDestroy(); }
}
