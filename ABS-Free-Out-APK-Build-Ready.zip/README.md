# ABS Free Out — GitHub APK Build ZIP

This ZIP contains the Android project and a GitHub Actions workflow for building a debug APK.

## Recommended setup (no terminal required)
1. Download this ZIP and extract it on your computer.
2. Open your GitHub repository.
3. Upload the **contents of the extracted folder** (including `.github`, `app`, `build.gradle`, `settings.gradle`, and `gradle.properties`) to the repository root. Make sure `.github/workflows/android-build.yml` is included.
4. Open **Actions → ABS Free Out APK Build**. If needed, select **Run workflow**.
5. When the run succeeds, open the run and download `abs-free-out-debug-apk` under **Artifacts**.

## If you want to upload the ZIP file itself
The repository must already have `.github/workflows/android-build.yml` from this package. Then upload `ABS-Free-Out-APK-Build-Ready.zip` to the repository root and push/commit it. The workflow can extract the ZIP and build it. Uploading a ZIP alone to a brand-new repository will not activate a workflow that is still inside that ZIP; GitHub only runs workflow files that are already present in `.github/workflows/` in the repository.

## Build details
- Java 17
- Android Gradle Plugin 8.6.1
- Gradle 8.7
- Android SDK / build tools 35
- Output: `app/build/outputs/apk/debug/app-debug.apk`

This ZIP fixes the earlier workflow ordering issue by ensuring the Gradle project exists before Gradle setup/build steps. A successful APK build cannot be guaranteed until GitHub Actions runs against your repository and resolves all dependencies.

## Server connection note
The Android app expects mobile API endpoints on your parking server. If the app installs but login or Free Out requests fail, inspect the server's API routes and response format; that is a runtime/server compatibility issue, separate from compiling the APK.
